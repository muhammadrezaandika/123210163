/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasprakpbo.ruang;

/**
 *
 * @author Dell
 */
public interface MenghitungRuang {
    double hitungVolume();
    double hitungLuasPermukaan();
}
