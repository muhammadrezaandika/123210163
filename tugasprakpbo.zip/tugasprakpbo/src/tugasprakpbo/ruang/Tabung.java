/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasprakpbo.ruang;

import tugasprakpbo.bidang.Lingkaran;

/**
 *
 * @author User
 */
public class Tabung extends Lingkaran implements MenghitungRuang {
    private double tinggi;

    public Tabung(double jariJari, double tinggi) {
        super(jariJari);
        this.tinggi = tinggi;
    }

    public double getTinggi() {
        return tinggi;
    }

    public void setTinggi(double tinggi) {
        this.tinggi = tinggi;
    }

    @Override
    public double hitungVolume() {
        return hitungLuas() * tinggi;
    }

    @Override
    public double hitungLuasPermukaan() {
        return (2 * super.hitungLuas()) + (hitungKeliling() * tinggi);
    }
}
