/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasprakpbo.bidang;

/**
 *
 * @author Dell
 */
public class Lingkaran implements MenghitungBidang {
    private final double jariJari;

    public Lingkaran(double jariJari) {
        this.jariJari = jariJari;
    }

    @Override
    public double hitungLuas() {
        return Math.PI * jariJari * jariJari;
    }

    /**
     *
     * @return
     */
    @Override
    public double hitungKeliling() {
        return 2 * Math.PI * jariJari;
    }
}
